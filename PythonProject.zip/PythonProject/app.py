from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///lab.db'
db = SQLAlchemy(app)


class UserType(db.Model):
    __tablename__ = 'user_type'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False)
    key = db.Column(db.String(80), unique=False, nullable=True)


class User(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    nickname = db.Column(db.String(80), unique=True, nullable=False)
    name = db.Column(db.String(80), nullable=False)
    last_name = db.Column(db.String(80), nullable=False)
    password = db.Column(db.String(80), nullable=False)
    usertype_id = db.Column(db.Integer, db.ForeignKey('user_type.id'))


class ObjectStatus(db.Model):
    __tablename__ = 'object_status'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)


class Object(db.Model):
    tablename = 'object'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(80), nullable=False)
    amount = db.Column(db.Text, nullable=False)
    userid = db.Column(db.Integer, db.ForeignKey('user.id'))
    objectstatusid = db.Column(db.Integer, db.ForeignKey('object_status.id'))



@app.route("/")
def main():
    return render_template("main.html")

@app.route("/pupil")
def pupil():
    return render_template("pupil.html")

@app.route("/admin")
def admin():
    return render_template("admin.html")

# @app.route("/", methods=['POST', 'GET'])
# def teacher_submit():
#     if request.method == 'POST':
#
#     else:
#         return render_template("main.html")
#
#
# @app.route("/", methods=['POST', 'GET'])
# def pupil_submit():
#     if request.method == 'POST':
#
#     else:
#         return render_template("main.html")



if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=80)