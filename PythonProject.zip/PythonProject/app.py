from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///lab.db'
db = SQLAlchemy(app)

with app.app_context():
    db.create_all()



class User(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    last_name = db.Column(db.String(80), nullable=False)
    password = db.Column(db.String(80), nullable=False)
    usertype = db.Column(db.String(80), nullable=False)

    def __init__(self, name, last_name, password, usertype):
        self.name = name
        self.last_name = last_name
        self.password = password
        self.usertype_id = usertype



class Object(db.Model):
    tablename = 'object'
    id = db.Column(db.Integer, primary_key=True)
    name_object = db.Column(db.String(80), nullable=False)
    amount = db.Column(db.Text, nullable=False)
    userid = db.Column(db.Integer, db.ForeignKey('user.id'))
    object_status = db.Column(db.String(80), nullable=False)

    def __init__(self, name_object, amount, userid, object_status):
        self.name_object = name_object
        self.amount = amount
        self.userid = userid
        self.object_status = object_status

class Tovar(db.Model):
    tablename = 'Tovar'
    id = db.Column(db.Integer, primary_key=True)
    name_tovar = db.Column(db.String(80), nullable=False)
    price = db.Column(db.Text, nullable=False)
    photo = db.Column(db.String(520), nullable=False)

    def __init__(self, name_tovar, price, photo):
        self.name_tovar = name_tovar
        self.price = price
        self.photo = photo

class Repair(db.Model):
    tablename = 'Tovar'
    id = db.Column(db.Integer, primary_key=True)
    tovar = db.Column(db.String(80), db.ForeignKey("name_tovar"))
    date = db.Column(db.Date, nullable=False)

    def __init__(self, tovar, date):
        self.tovar = tovar
        self.date = date



@app.route("/")
def register():
    return render_template("main.html")

@app.route("/admin")
def admin():
    return render_template("admin.html")
@app.route("/user")
def user():
    return render_template("user.html")
@app.route("/inventory")
def inventory():
    return render_template("inventory.html")
@app.route("/otchot")
def otchot():
    return render_template("otchot.html")
@app.route("/order")
def order():
    return render_template("order.html")
@app.route("/zakrep")
def zakrep():
    return render_template("zakrep.html")
@app.route("/zakupki")
def zakupki():
    return render_template("zakupki.html")
@app.route("/inventory_user")
def inventory_user():
    return render_template("inventory_user.html")
@app.route("/order_user")
def order_user():
    return render_template("order_user.html")

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=80)