//document.getElementById("main_btn").addEventListener("click", () => {
//    document.getElementById("overlay").classList.remove("hidden");
//    document.getElementById("selectModal").classList.remove("hidden");
//    document.getElementById("selectModal").style.display = "flex";
//});
//document.getElementById("LogBtnAdmin").addEventListener("click", () => {
//    document.getElementById("overlay").classList.remove("hidden");
//    document.getElementById("loginModal").classList.remove("hidden");
//    document.getElementById("loginModal").style.display = "flex";
//    document.getElementById("selectModal").classList.add("hidden");
//    document.getElementById("selectModal").style.display = "none";
//});
//document.getElementById("LogBtnPupil").addEventListener("click", () => {
//    document.getElementById("overlay").classList.remove("hidden");
//    document.getElementById("loginModal").classList.remove("hidden");
//    document.getElementById("loginModal").style.display = "flex";
//    document.getElementById("selectModal").classList.add("hidden");
//    document.getElementById("selectModal").style.display = "none";
//});
//document.getElementById("closeLogin").addEventListener("click", () => {
//    document.getElementById("overlay").classList.add("hidden");
//    document.getElementById("loginModal").classList.add("hidden");
//    document.getElementById("loginModal").style.display = "none";
//});
//document.getElementById("closeSelect").addEventListener("click", () => {
//    document.getElementById("overlay").classList.add("hidden");
//    document.getElementById("selectModal").classList.add("hidden");
//    document.getElementById("selectModal").style.display = "none";
//});




    // Функционал открытия и закрытия модальных окон
//document.getElementById("loginBtn").addEventListener("click", () => {
//        document.getElementById("overlay").style.display = "block";
//});

    document.getElementById("registerBtn").addEventListener("click", () =>  {
        document.getElementById("registerOverlay").style.display = "block";
    })

    function openModal(modalId) {
        document.getElementById(modalId).style.display = "block";
    }

    function closeModal(modalId) {
        document.getElementById(modalId).style.display = "none";
        clearErrors(modalId);
    }

    function clearErrors(modalId) {
        const errors = document.querySelectorAll({modalId} .error);
        errors.forEach(error => error.style.display = "none");
    }

    document.querySelectorAll(".close").forEach(function (closeButton) {
        closeButton.onclick = function () {
            closeModal(closeButton.closest('.modal').id);
        };
    });

window.onclick = function (event) {
        if (event.target.classList.contains('modal')) {
            closeModal(event.target.id);
        }
    };

    // Вход администратора
    document.getElementById("adminLoginBtn").onclick = function () {
        openModal("adminPanel");
        closeModal("overlay");
    }

    // Вход пользователя
    document.getElementById("userLoginBtn").onclick = function () {
        openModal("userPanel");
        closeModal("overlay");
    }

    // Регистрация как учитель
    document.getElementById("teacherRegisterBtn").onclick = function () {
        openModal("teacherPanel");
        closeModal("registerOverlay");
    }

    // Регистрация как ученик
    document.getElementById("studentRegisterBtn").onclick = function () {
        openModal("studentPanel");
        closeModal("registerOverlay");
    }

    // Обработка входа администратора
    document.getElementById("adminSubmitBtn").onclick = function () {
        const nickname = document.getElementById("adminNickname").value;
        const password = document.getElementById("adminPassword").value;
        const key = document.getElementById("adminKey").value;
        let isValid = true;

        if (nickname === "") {
            document.getElementById("adminNicknameError").style.display = "block";
            isValid = false;
        }
        if (password === "") {
            document.getElementById("adminPasswordError").style.display = "block";
            isValid = false;
        }
        if (key === "") {
            document.getElementById("adminKeyError").style.display = "block";
            isValid = false;
        }

        if (isValid) {
            closeModal("adminPanel");
            document.getElementById("successMessage").style.display = "block";
        }
    }

    // Обработка входа пользователя
    document.getElementById("userSubmitBtn").onclick = function () {
        const nick = document.getElementById("userNick").value;
        const password = document.getElementById("userPassword").value;
        let isValid = true;

        if (nick === "") {
            document.getElementById("userNickError").style.display = "block";
            isValid = false;
        }
        if (password === "") {
            document.getElementById("userPasswordError").style.display = "block";
            isValid = false;
        }

        if (isValid) {
            closeModal("userPanel");
            document.getElementById("successMessage").style.display = "block";
        }
    }

    // Обработка регистрации учителя
    document.getElementById("teacherSubmitBtn").onclick = function () {
        const nick = document.getElementById("teacherNick").value;
        const name = document.getElementById("teacherName").value;
        const lastname = document.getElementById("teacherLastname").value;
        const password = document.getElementById("teacherPassword").value;
        const key = document.getElementById("teacherKey").value;
        let isValid = true;

        if (nick === "") {
            document.getElementById("teacherNickError").style.display = "block";
            isValid = false;
        }
        if (name === "") {
            document.getElementById("teacherNameError").style.display = "block";
            isValid = false;
        }
        if (lastname === "") {
            document.getElementById("teacherLastnameError").style.display = "block";
            isValid = false;
        }
        if (password === "") {
            document.getElementById("teacherPasswordError").style.display = "block";
            isValid = false;
        }
        if (key === "") {
            document.getElementById("teacherKeyError").style.display = "block";
            isValid = false;
        }

        if (isValid) {
            closeModal("teacherPanel");
            document.getElementById("successMessage").style.display = "block";
        }
    }
    function fun(e){
        e.preventDefault()
        window.location.href="/admin"
    }
