from flask import Flask
from models import db, UserType, Object, ObjectStatus
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///lab.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)
if __name__ == "__main__":
        with app.app_context():
                db.drop_all()
                db.create_all()

                usertype1 = UserType(name="Ученик")
                usertype2 = UserType(name="Физрук")

                db.session.add_all([usertype1, usertype2])

                Object1 = Object(title="Мяч", amount=52)
                Object2 = Object(title="Скакалка", amount=19)
                Object3 = Object(title="Гриша", amount=1488)

                db.session.add_all([Object1, Object2, Object3])

                Objectstatus1 = ObjectStatus(name="Доступно")
                Objectstatus2 = ObjectStatus(name="Забронировано")
                Objectstatus3 = ObjectStatus(name="Выдано")
                Objectstatus4 = ObjectStatus(name="Сломано :(")

                db.session.add_all([Objectstatus1, Objectstatus2, Objectstatus3, Objectstatus4])

                db.session.commit()
